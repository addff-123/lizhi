/* ========================================
   助兴乡野·好物出山 — 全局交互脚本
   ======================================== */

document.addEventListener('DOMContentLoaded', () => {
  initReveal();
  initNavbar();
  initTabs();
  initCounters();
  initProgressBars();
  initMobileNav();
  initParallax();
  initCountdown();
});

/* ---------- 滚动渐入 ---------- */
function initReveal() {
  const reveals = document.querySelectorAll('.reveal');
  if (!reveals.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  reveals.forEach(el => observer.observe(el));
}

/* ---------- 导航栏滚动效果 ---------- */
function initNavbar() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  let lastScroll = 0;
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    if (currentScroll > 60) {
      navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.06)';
    } else {
      navbar.style.boxShadow = 'none';
    }
    lastScroll = currentScroll;
  });
}

/* ---------- Tab 切换 ---------- */
function initTabs() {
  document.querySelectorAll('.tab-nav').forEach(nav => {
    const btns = nav.querySelectorAll('.tab-btn');
    const panels = nav.closest('.tabs-container')?.querySelectorAll('.tab-panel')
      || document.querySelectorAll('.tab-panel');

    btns.forEach((btn, idx) => {
      btn.addEventListener('click', () => {
        btns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        panels.forEach(p => p.classList.remove('active'));
        if (panels[idx]) panels[idx].classList.add('active');
      });
    });
  });
}

/* ---------- 数字滚动计数器 ---------- */
function initCounters() {
  const counters = document.querySelectorAll('[data-counter]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
}

function animateCounter(el) {
  const target = parseInt(el.dataset.counter, 10);
  const suffix = el.dataset.suffix || '';
  const duration = 2000;
  const startTime = performance.now();

  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = Math.floor(ease * target);
    el.textContent = current + suffix;
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

/* ---------- 进度条动画 ---------- */
function initProgressBars() {
  const bars = document.querySelectorAll('[data-progress]');
  if (!bars.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const fill = entry.target.querySelector('.progress-fill');
        if (fill) fill.style.width = entry.target.dataset.progress + '%';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  bars.forEach(el => observer.observe(el));
}

/* ---------- 移动端导航 ---------- */
function initMobileNav() {
  const toggle = document.querySelector('.nav-mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (!toggle || !navLinks) return;

  toggle.addEventListener('click', () => {
    navLinks.classList.toggle('mobile-open');
    const isOpen = navLinks.classList.contains('mobile-open');
    navLinks.style.display = isOpen ? 'flex' : 'none';
    navLinks.style.position = 'absolute';
    navLinks.style.top = '72px';
    navLinks.style.left = '0';
    navLinks.style.right = '0';
    navLinks.style.flexDirection = 'column';
    navLinks.style.background = '#fff';
    navLinks.style.padding = '20px';
    navLinks.style.boxShadow = '0 10px 30px rgba(0,0,0,0.08)';
    navLinks.style.gap = '16px';
    navLinks.style.zIndex = '999';
  });
}

/* ---------- 视差效果 ---------- */
function initParallax() {
  const parallaxElements = document.querySelectorAll('.parallax-img');
  if (!parallaxElements.length) return;

  window.addEventListener('scroll', () => {
    const scrollY = window.pageYOffset;
    parallaxElements.forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        const speed = el.dataset.speed || 0.1;
        el.style.transform = `translateY(${(rect.top - window.innerHeight / 2) * speed}px)`;
      }
    });
  });
}

/* ---------- 倒计时 ---------- */
function initCountdown() {
  const countdownEls = document.querySelectorAll('.countdown-box[data-target]');
  countdownEls.forEach(box => {
    const targetDate = new Date(box.dataset.target).getTime();
    const items = box.querySelectorAll('.countdown-item');
    if (!items.length) return;

    function update() {
      const now = Date.now();
      const diff = targetDate - now;
      if (diff <= 0) return;

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const mins = Math.floor((diff / (1000 * 60)) % 60);
      const secs = Math.floor((diff / 1000) % 60);

      const vals = [days, hours, mins, secs];
      items.forEach((item, i) => {
        const num = item.querySelector('.num');
        if (num && vals[i] !== undefined) {
          num.textContent = String(vals[i]).padStart(2, '0');
        }
      });
    }
    update();
    setInterval(update, 1000);
  });
}

/* ---------- 平滑滚动到锚点 ---------- */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
